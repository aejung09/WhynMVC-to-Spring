package com.springlec.whyn.alogin;

public interface ALoginDao {
	
	public int aloginchecked(String id, String pw);

}

package com.springlec.whyn.winelist;

public class WCommand {

}

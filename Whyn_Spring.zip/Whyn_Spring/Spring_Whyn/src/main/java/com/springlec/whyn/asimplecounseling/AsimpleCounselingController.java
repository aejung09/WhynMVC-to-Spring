package com.springlec.whyn.asimplecounseling;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//@Controller
public class AsimpleCounselingController {
//	@Autowired
//	private SqlSession sqlSession;//sql 세션 불러오기
}

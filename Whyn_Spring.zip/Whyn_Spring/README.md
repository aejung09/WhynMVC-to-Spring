# Wyne_Spring

## 패키지 패턴

    - ex)// com.springlec.controller.join//  //com.springlec.dao.mapper.join //com.springlec.dao.join//     com.springlec.dto.join
      //com.springlec.admin.login.dao // com.spring.admin.join.dao                  

## Dao, Dto
    - ex) LoginDao , LoginDto  // JoinDao, JoinDto,..


## JSP
    - ex) admin_subscribe, admin_counseiling_Management, admin_counseling_ContentView
          admin_deliveryView,...


## Controller
    - ex) Controller_Login , Controller_Join,...


## 주석처리 무조건  

         ///////////////////////////////////
         // Date : 2021.01.21 (목) - 태현 
         // 로그인 컨트롤러,...등등. 
         ///////////////////////////////////

## 커밋 시
        -ex) 2021.01.21 이름 
        (설명플리즈)

